/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package coe528.Project;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author Seanan
 */
public class Electronics extends Categories {

    private String product, name;
    private double price;
    private int quantity;

    List<Electronics> electronics = new ArrayList<>();

    public Electronics(String name, double price, int q) {
        this.name = name;
        this.price = price;
        this.quantity = q;

    }

    public List products() {

        int i = 0;

        double p;
        int q;
        String[] details;
        try {
            File f = new File("electronics.txt");
            //Scanner sc = new Scanner(f);

            FileReader fr = new FileReader(f);
            BufferedReader br = new BufferedReader(fr);
            String abc;
            while ((abc = br.readLine()) != null) {
                details = abc.split(":");
                String name = details[0];
                p = Double.parseDouble(details[1]);
                q = Integer.parseInt(details[2]);
                Electronics electronic = new Electronics(name, p, q);
                electronics.add(electronic);

            }
            br.close();
            fr.close();

        } catch (Exception e) {
            System.out.println("ERROR");
            e.printStackTrace();
        }
        return electronics;
    }

    public void searchproducts(String input) {
        for (int i = 0; i < electronics.size(); i++) {
            electronics.get(i).name.contentEquals(input);
            System.out.println(electronics.get(i));
        }

    }

    public void addProduct(String name, double price, int quantity) {
        int flag = 0;
        double p;
        int q;
        for (int i = 0; i < electronics.size(); i++) {
            if (electronics.get(i).name.contentEquals(name)) {
                flag = 1;
            }
        }

        if (flag == 0) {
            FileWriter fr = null;

            Electronics elec = new Electronics(name, price, quantity);
            electronics.add(elec);
            System.out.println("The product was successfully added");
            //PrintWriter writer = new PrintWriter("electronics.txt");
            //writer.print("");
            //writer.close();
            // File f = new File("electronics.txt");
            //fr = new FileWriter(f);
            //BufferedWriter br = new BufferedWriter(fr);
            try (PrintWriter out = new PrintWriter(new BufferedWriter(new FileWriter("electronics.txt", true)))) {
                p = price;
                q = quantity;
                out.print(name + ":" + p + ":" + q);
            } catch (IOException e) {
            }

        } else {
            System.out.println("Name already exists");
        }
    }

    public void removeProduct(String input) {
        int flag = 0;
        for (int i = 0; i < electronics.size(); i++) {
            if (electronics.get(i).getName().equalsIgnoreCase(input) == true) {
                flag = 1;
                electronics.remove(i);
                System.out.println("was removed successfully");
                try {
                    PrintWriter writer = new PrintWriter("electronics.txt");
                    writer.print("");
                    writer.close();
                    File f = new File("electronics.txt");
                    FileWriter fr = new FileWriter(f);
                    BufferedWriter br = new BufferedWriter(fr);
                    for (int j = 0; j < electronics.size(); j++) {
                        br.write(electronics.get(j).getName() + ":" + electronics.get(j).getPrice() + ":" + electronics.get(j).getQuantity());
                        br.newLine();
                    }
                    br.close();
                } catch (Exception e) {

                }
                break;
            }
        }
        if (flag == 0) {
            System.out.println("No such product exist");
        }

    }

    public void setProduct(String product) {
        this.product = product;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void setPrice(double price) {
        this.price = price;
    }

    public void setQuantity(int quantity) {
        this.quantity = quantity;
    }

    public String getProduct() {
        return product;
    }

    public String getName() {
        return name;
    }
//use this method for getting the price 
    public double returnPrice(String input){
        for (int i = 0; i <= electronics.size(); i++) {
            if (electronics.get(i).getName().equalsIgnoreCase(input) == true) {
                
                return (electronics.get(i).getPrice());
            
            }
        }
        return 0;
            
    }
    
    public double getPrice() {

        return price;
    }

    public int getQuantity() {
        return quantity;
    }

    public List<Electronics> getElectronics() {
        return electronics;
    }

    public void setElectronics(List<Electronics> electronics) {
        this.electronics = electronics;
    }

    public void modifyprice(String input, double price) {

        int flag = 0;
        for (int i = 0; i <= electronics.size(); i++) {
            if (electronics.get(i).getName().equalsIgnoreCase(input) == true) {
                flag = 1;
                electronics.get(i).setPrice(price);
                try {
                    PrintWriter writer = new PrintWriter("electronics.txt");
                    writer.print("");
                    writer.close();
                    File f = new File("electronics.txt");
                    FileWriter fr = new FileWriter(f);
                    BufferedWriter br = new BufferedWriter(fr);
                    for (int j = 0; j < electronics.size(); j++) {
                        br.write(electronics.get(j).getName() + ":" + electronics.get(j).getPrice() + ":" + electronics.get(j).getQuantity());
                        br.newLine();
                    }
                    br.close();
                } catch (Exception e) {

                }
                break;
            }
        }

        if (flag == 0) {
            System.out.println("No such product exist");
        }
    }

    public void modifyquantity(String input, int quantity) {

        int flag = 0;
        for (int i = 0; i <= electronics.size(); i++) {
            if (electronics.get(i).getName().equalsIgnoreCase(input) == true) {
                flag = 1;
                electronics.get(i).setQuantity(quantity);
                try {
                    PrintWriter writer = new PrintWriter("electronics.txt");
                    writer.print("");
                    writer.close();
                    File f = new File("electronics.txt");
                    FileWriter fr = new FileWriter(f);
                    BufferedWriter br = new BufferedWriter(fr);
                    for (int j = 0; j < electronics.size(); j++) {
                        br.write(electronics.get(j).getName() + ":" + electronics.get(j).getPrice() + ":" + electronics.get(j).getQuantity());
                        br.newLine();
                    }
                    br.close();
                } catch (Exception e) {

                }
                break;
            }
        }

        if (flag == 0) {
            System.out.println("No such product exist");
        }
    }

    @Override
    public String toString() {
        return this.name + " " + this.price + " " + this.quantity; //To change body of generated methods, choose Tools | Templates.
    }

    public void viewproducts() {
        for (Electronics e : electronics) {
            System.out.println(e.toString());
        }

    }
}
