/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package coe528.Project;

import java.util.List;
import java.util.Scanner;

/**
 *
 * @author Akash
 */
public class facade {

    private Categories a, b, c;

    public facade() {

        a = new Electronics("a", 22, 11);
        b = new Clothing("a", 22, 11);
        c = new Sports("a", 22, 11);
        this.create_categories();
    }

    //customer related functions
    private void create_categories() {
        a.products();
        b.products();
        c.products();
    }

    public void manageroperations() {
        int choice, q;
        String name;
        double price;
        Scanner s = new Scanner(System.in);
        System.out.println("What would you like to do  :\n1.Add Product\n2.Remove Product\n3.Modify Quantity\n4.Modify Price\n5.Logout");
        choice = s.nextInt();
        while (choice != 5) {
            switch (choice) {
                case 1:
                    System.out.println("In which category: :\n1.Electronics\n2.Sports\n3.Clothing");
                    choice = s.nextInt();

                    switch (choice) {
                        case 1:
                            System.out.println("Enter the product name");
                            name = s.next();

                            System.out.println("Enter the price of the product");
                            price = s.nextDouble();
                            System.out.println("Enter the quantity");
                            q = s.nextInt();
                            a.addProduct(name, price, q);
                            break;

                        case 2:
                            System.out.println("Enter the product name");
                            name = s.next();
                            System.out.println("Enter the price of the product");
                            price = s.nextDouble();
                            System.out.println("Enter the quantity");
                            q = s.nextInt();
                            c.addProduct(name, price, q);
                            break;

                        case 3:
                            System.out.println("Enter the product name");
                            name = s.next();
                            System.out.println("Enter the price of the product");
                            price = s.nextDouble();
                            System.out.println("Enter the quantity");
                            q = s.nextInt();
                            b.addProduct(name, price, q);
                            break;
                        default:
                            System.out.println("\nWrong choice entered");

                    }

                    break;
                case 2:
                    System.out.println("In which category: :\n1.Electronics\n2.Sports\n3.Clothing");
                    choice = s.nextInt();

                    switch (choice) {
                        case 1:
                            System.out.println("Enter the name of the product to delete");
                            name = s.next();
                            a.removeProduct(name);
                            break;

                        case 2:
                            System.out.println("Enter the name of the product to delete");
                            name = s.next();
                            c.removeProduct(name);
                            break;

                        case 3:
                            System.out.println("Enter the name of the product to delete");
                            name = s.next();
                            b.removeProduct(name);
                            break;
                        default:
                            System.out.println("\nWrong choice entered");

                    }
                    break;
                case 3:
                    System.out.println("In which category: :\n1.Electronics\n2.Sports\n3.Clothing");
                    choice = s.nextInt();

                    switch (choice) {
                        case 1:
                            System.out.println("Enter the name of the product to change its quantity");
                            name = s.next();
                            System.out.println("Enter the new quantity");
                            q = s.nextInt();
                            a.modifyquantity(name, q);
                            break;

                        case 2:
                            System.out.println("Enter the name of the product to change its quantity");
                            name = s.next();
                            System.out.println("Enter the new quantity");
                            q = s.nextInt();
                            c.modifyquantity(name, q);
                            break;
                        case 3:
                            System.out.println("Enter the name of the product to change its quantity");
                            name = s.next();
                            System.out.println("Enter the new quantity");
                            q = s.nextInt();
                            b.modifyquantity(name, q);
                            break;
                        default:
                            System.out.println("\nWrong choice entered");
                    }
                    break;
                case 4:
                    System.out.println("In which category: :\n1.Electronics\n2.Sports\n3.Clothing");
                    choice = s.nextInt();

                    switch (choice) {
                        case 1:
                            System.out.println("Enter the name of the product to change its price");
                            name = s.next();
                            System.out.println("Enter the new price");
                            price = s.nextInt();
                            a.modifyprice(name, price);
                            break;

                        case 2:
                            System.out.println("Enter the name of the product to change its price");
                            name = s.next();
                            System.out.println("Enter the new price");
                            price = s.nextInt();
                            c.modifyprice(name, price);
                            break;

                        case 3:
                            System.out.println("Enter the name of the product to change its price");
                            name = s.next();
                            System.out.println("Enter the new price");
                            price = s.nextInt();
                            b.modifyprice(name, price);
                            break;
                        default:
                            System.out.println("\nWrong choice entered");
                    }
                    break;

                default:
                    System.out.println("\nWrong choice entered");

            }
            System.out.println("What would you like to do  :\n1.Add Product\n2.Remove Product\n3.Modify Quantity\n4.Modify Price\n5.Logout");
            choice = s.nextInt();
        }
    }

    public void view_products() {
        int choice;
        Scanner s = new Scanner(System.in);
        System.out.println("Enter Category :\n1.Electronics\n2.Clothing\n3.Sports");
        choice = s.nextInt();

        switch (choice) {
            case 1:
                a.products();
                a.viewproducts();
                break;
            case 2:
                b.viewproducts();
                break;
            case 3:
                c.viewproducts();
                break;
            default:
                System.out.println("\nWrong choice entered");
        }

    }
    //public void pay(){
    //yet to be implemented
    //}    
    //manager related functions

    public void setPrice() {

    }

    public void manager() {

    }

    public void customer() {

    }

    public void registered_customer() {

    }

    //cart related functions
    /*public abstract void add_to_cart();
    
     public abstract void view_cart();*/
}
