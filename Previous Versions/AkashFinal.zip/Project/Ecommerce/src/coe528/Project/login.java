/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package coe528.Project;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.Scanner;

/**
 *
 * @author Akash
 */
public class login {
    static Scanner s;
    static File f1,f2;
    static FileReader fr;
    static BufferedReader br;
    static String username,password,line;
    manager m;
    boolean u,p;
    public login()
    {
        username="";
        password="";
        f1=new File("username.txt");
        f2=new File("password.txt");           
        u=false;
        p=false;
    }
    public void enter_username() throws FileNotFoundException, IOException
    {
        s=new Scanner(System.in);
         System.out.println("\nEnter username");
         username=s.nextLine();
         fr=new FileReader(f1);
         br=new BufferedReader(fr);

         while((line=br.readLine())!=null)
         { if(line.equals(username)){
                 u=true; break;}
          
         System.out.println("");
         }
         System.out.println("\nUsername found,Now checking password...");
    u=true;
    }
    
    public void enter_password() throws FileNotFoundException, IOException
    {
        s=new Scanner(System.in);
         System.out.println("Enter password");  
         password=s.next();
         fr=new FileReader(f2);
         br=new BufferedReader(fr);
         while((line=br.readLine())!=null)
         {   if(line.equals(password)){
                  p=true;break;         }
             System.out.println("");
         }
             System.out.println("\nPassword checked,Now logging in...");                 
    
    
    }
    
    public void role()
    {
        if("admin".equals(username) && "admin".equals(password))
        {
            System.out.println("\nLogged in as manager");
            m=new manager();
            m.manageroperations();
            
        
        }
        else if(u==true&&p==true)
        {
            System.out.println("\nLogged in as Registered Customer");
            registered_customer rc=new registered_customer();
            rc.registered_customer_operations();
        }
        else
        {
            System.out.println("\n\nTRY AGAIN");
        }
    }
    
}
