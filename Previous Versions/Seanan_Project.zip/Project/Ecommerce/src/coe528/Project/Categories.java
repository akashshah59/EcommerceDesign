/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package coe528.Project;

import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author Seanan
 */
public class Categories{
    

    // public abstract void list();
    //public abstract void addToCart();
    // public abstract void getPrice();
 
    ArrayList products = new ArrayList<>();
    
    public void viewproducts(){
        
    }
    
    public List products(){
        return null;
    }
 
}
